BACK UP YOUR GD RESOURCES FOLDER BEFORE RUNNING THIS PROGRAM!
C:\Program Files (x86)\Steam\steamapps\common\Geometry Dash\Resources
(just make a copy of the folder or something)

===

In a nutshell, this program randomizes all the GD textures.
To keep things tidy, textures will only be replaced with similar-sized ones.
All icons are also randomized.
It's also compatible with texture packs!

===

HOW TO USE:
- Run the "shuffle.exe" file.
- When it finishes, drag the files in the "pack" folder into your GD resources folder.
- When asked to overwrite files, click yes.

===

If the program closes as soon as you open it, that means it crashed.
A file called crash_log.txt will be created - send it to Colon and he'll hopefully get around to fixing it.